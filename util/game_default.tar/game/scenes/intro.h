class SceneIntro : public Scene {
public:
	SceneIntro(Scene::Controller *ctrl) : Scene(ctrl) {
	}

	~SceneIntro(){
	}
};
